from pathlib import Path
import pandas as pd, json, time, sys, importlib.util
ROOT=Path('/mnt/data/selective_firewall');OUT=ROOT/'results_bridge_mild';OUT.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('gf',ROOT/'run_firewall_v2_guardfixed.py');m=importlib.util.module_from_spec(spec);sys.modules['gf']=m;spec.loader.exec_module(m)
Cfg=m.Cfg
cs=[]
for n in [3,5,8]:
 for alloc in [.25,.40]:
  base=dict(selection='cohort',trigger=.12,rank_n=n,cut_scale=.50,amber_scale=1.,refresh_depth=.05,systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=alloc)
  cs.append(Cfg(f'base_n{n}_sys{alloc}',**base))
  for cap in [.05,.10,.15]:
   for target in [.90,.95]:
    cs.append(Cfg(f'SSO_n{n}_sys{alloc}_cap{cap}_target{target}',**base,bridge_asset='SSO',bridge_cap=cap,bridge_target_beta=target,bridge_max_days=40))
  cs.append(Cfg(f'SPY_n{n}_sys{alloc}_cap20_target95',**base,bridge_asset='SPY',bridge_leverage=1.,bridge_cap=.20,bridge_target_beta=.95,bridge_max_days=40))

def main():
 t=time.time();core,panel,entries,diag=m.fw.load_data();pg,eg=m.precompute(core,panel,entries);rows=[]
 for i,c in enumerate(cs):
  s,tr,r,d=m.simulate(core,pg,eg,diag,c,False);rows.append(r);print(i+1,c.name,round(r['cagr'],6),round(r['max_drawdown'],6),r['bridge_entries'],flush=True)
 res=pd.DataFrame(rows);res['min_calmar']=res[['calmar','trailing15_calmar','trailing10_calmar']].min(axis=1);res.to_csv(OUT/'bridge_mild_grid.csv',index=False)
 top=res.sort_values(['min_calmar','cagr'],ascending=False).head(8).name.tolist();details=[]
 for name in top:
  c=next(x for x in cs if x.name==name);s,tr,r,d=m.simulate(core,pg,eg,diag,c,True);d.to_csv(OUT/f'{name}_daily.csv');tr.to_csv(OUT/f'{name}_transitions.csv',index=False);m.fw.crisis_metrics(s).to_csv(OUT/f'{name}_crisis.csv',index=False);details.append(r)
 pd.DataFrame(details).to_csv(OUT/'selected.csv',index=False);print('TOP',res.sort_values(['min_calmar','cagr'],ascending=False)[['name','cagr','max_drawdown','calmar','ending_multiple','trailing10_cagr','trailing10_max_drawdown','bridge_entries','average_bridge_weight','min_calmar']].head(12).to_dict('records'));print('DONE',time.time()-t)
if __name__=='__main__':main()
