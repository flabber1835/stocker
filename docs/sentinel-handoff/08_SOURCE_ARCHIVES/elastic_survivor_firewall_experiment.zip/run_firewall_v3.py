from pathlib import Path
import pandas as pd, json, time, sys, importlib.util
ROOT=Path('/mnt/data/selective_firewall');OUT=ROOT/'results_v3';OUT.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('fwv2',ROOT/'run_firewall_v2_fixed.py')
m=importlib.util.module_from_spec(spec);sys.modules['fwv2']=m;spec.loader.exec_module(m)
Cfg=m.Cfg

def configs():
 c=[Cfg('Wealth Core baseline'),Cfg('binary25',systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=.25),Cfg('binary40',systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=.40)]
 # Natural contraction only: no proactive cuts, leave ordinary-stop vacancies empty during stress.
 for trig in [.08,.10,.12]:
  for caps in [(23,21,18),(22,20,17),(20,17,12)]:
   c.append(Cfg(f'natural_contract_t{trig:.2f}_{caps[0]}_{caps[1]}_{caps[2]}',selection='none',trigger=trig,entry_policy='position_cap',position_caps=caps))
   for alloc in [.25,.40]:
    c.append(Cfg(f'natural_contract_t{trig:.2f}_{caps[0]}_{caps[1]}_{caps[2]}_sys{alloc:.2f}',selection='none',trigger=trig,entry_policy='position_cap',position_caps=caps,systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=alloc))
 # Only reject weak replacement candidates during stress.
 for trig in [.08,.10,.12]:
  c.append(Cfg(f'weak_entry_gate_t{trig:.2f}',selection='none',trigger=trig,entry_policy='weak'))
 # Mild survivor trims and combinations with systemic protection.
 for n in [3,5,8]:
  for refresh in [.05,.99]:
   base=dict(selection='cohort',trigger=.12,rank_n=n,cut_scale=.50,amber_scale=1.,refresh_depth=refresh)
   c.append(Cfg(f'mild_t12_n{n}_r{refresh}',**base))
   for alloc in [.25,.40]:c.append(Cfg(f'mild_t12_n{n}_r{refresh}_sys{alloc:.2f}',**base,systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=alloc))
 # Recovery bridges on pure binary and on best expected mild architecture.
 for alloc in [.25,.40]:
  for cap in [.05,.10,.15]:
   for days in [20,40,60]:
    c.append(Cfg(f'binary{alloc:.2f}_SSO{cap:.2f}_{days}',systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=alloc,bridge_asset='SSO',bridge_cap=cap,bridge_max_days=days))
 # SPY 1x bridge control versus SSO 2x.
 for alloc in [.25,.40]:
  c.append(Cfg(f'binary{alloc:.2f}_SPY20_40',systemic_trigger=.155,systemic_breadth=2.,systemic_alloc=alloc,bridge_asset='SPY',bridge_leverage=1.,bridge_cap=.20,bridge_max_days=40))
 return c

def main():
 t=time.time();core,panel,entries,diag=m.fw.load_data();pg,eg=m.precompute(core,panel,entries);cs=configs();rows=[];curves={}
 print('DATA',len(core),len(panel),len(entries),'CONFIGS',len(cs),flush=True)
 for i,cfg in enumerate(cs):
  s,tr,r,d=m.simulate(core,pg,eg,diag,cfg,False);rows.append(r);curves[cfg.name]=s
  if i%10==0 or i==len(cs)-1:print('RUN',i+1,cfg.name,round(r['cagr'],5),round(r['max_drawdown'],5),flush=True)
 res=pd.DataFrame(rows);res['min_calmar']=res[['calmar','trailing15_calmar','trailing10_calmar']].min(axis=1);res['mean_calmar']=res[['calmar','trailing15_calmar','trailing10_calmar']].mean(axis=1);res.to_csv(OUT/'v3_grid.csv',index=False)
 selected=['Wealth Core baseline','binary25','binary40']
 selected += res[res.name.str.startswith('natural_contract')].sort_values(['min_calmar','cagr'],ascending=False).head(4).name.tolist()
 selected += res[res.name.str.startswith('weak_entry')].sort_values('cagr',ascending=False).head(1).name.tolist()
 selected += res[res.name.str.startswith('mild_')].sort_values(['min_calmar','cagr'],ascending=False).head(5).name.tolist()
 selected += res[res.name.str.contains('_SSO|_SPY')].sort_values(['min_calmar','cagr'],ascending=False).head(5).name.tolist()
 selected=list(dict.fromkeys(selected));details=[]
 for name in selected:
  cfg=next(x for x in cs if x.name==name);s,tr,r,d=m.simulate(core,pg,eg,diag,cfg,True);d.to_csv(OUT/f'{name}_daily.csv');tr.to_csv(OUT/f'{name}_transitions.csv',index=False);m.fw.crisis_metrics(s).to_csv(OUT/f'{name}_crisis.csv',index=False);details.append(r)
 pd.DataFrame(details).to_csv(OUT/'v3_selected.csv',index=False)
 (OUT/'metadata.json').write_text(json.dumps({'runtime_seconds':time.time()-t,'configs':len(cs)},indent=2))
 print('TOP',res.sort_values(['min_calmar','cagr'],ascending=False)[['name','cagr','max_drawdown','calmar','trailing10_cagr','trailing10_max_drawdown','min_calmar']].head(10).to_dict('records'),flush=True)
 print('DONE',round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
