from pathlib import Path
import pandas as pd, json, time, sys, importlib.util
ROOT=Path('/mnt/data/selective_firewall');OUT=ROOT/'results_position_count';OUT.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('gf',ROOT/'run_firewall_v2_guardfixed.py');m=importlib.util.module_from_spec(spec);sys.modules['gf']=m;spec.loader.exec_module(m)
Cfg=m.Cfg
cs=[Cfg('Wealth Core baseline')]
for trig in [.08,.10,.12]:
 for caps in [(24,22,20),(23,21,18),(22,20,17),(20,17,12)]:
  cs.append(Cfg(f'natural_t{trig:.2f}_{caps}',selection='none',trigger=trig,entry_policy='position_cap',position_caps=caps))
  cs.append(Cfg(f'naturalweak_t{trig:.2f}_{caps}',selection='none',trigger=trig,entry_policy='weak',position_caps=caps))
for trig in [.08,.10,.12]:cs.append(Cfg(f'weakonly_t{trig:.2f}',selection='none',trigger=trig,entry_policy='weak'))

def main():
 t=time.time();core,panel,entries,diag=m.fw.load_data();pg,eg=m.precompute(core,panel,entries);rows=[];curves={}
 for i,c in enumerate(cs):
  s,tr,r,d=m.simulate(core,pg,eg,diag,c,False);rows.append(r);curves[c.name]=s;print(i+1,c.name,round(r['cagr'],5),round(r['max_drawdown'],5),flush=True)
 res=pd.DataFrame(rows);res['min_calmar']=res[['calmar','trailing15_calmar','trailing10_calmar']].min(axis=1);res.to_csv(OUT/'position_count_grid.csv',index=False)
 top=res.sort_values(['min_calmar','cagr'],ascending=False).head(8).name.tolist();details=[]
 for name in ['Wealth Core baseline']+top:
  c=next(x for x in cs if x.name==name);s,tr,r,d=m.simulate(core,pg,eg,diag,c,True);d.to_csv(OUT/f'{name}_daily.csv');tr.to_csv(OUT/f'{name}_transitions.csv',index=False);m.fw.crisis_metrics(s).to_csv(OUT/f'{name}_crisis.csv',index=False);details.append(r)
 pd.DataFrame(details).to_csv(OUT/'selected.csv',index=False);print('TOP',res.sort_values(['min_calmar','cagr'],ascending=False)[['name','cagr','max_drawdown','calmar','trailing10_cagr','trailing10_max_drawdown','average_live_positions','blocked_entries','min_calmar']].head(12).to_dict('records'));print('DONE',time.time()-t)
if __name__=='__main__':main()
