import json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

phase = sys.argv[1]
root = Path(tempfile.mkdtemp(prefix='prenas-'+phase+'-')) / 'source'
root.parent.chmod(0o755)  # postgres must traverse to the production WAL script.
subprocess.run(['git','clone','--quiet','--depth','1','--single-branch','--branch',
    'codex/economic-audit-remediation','file:///repo',str(root)],check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head == '354a431a053886d2267438997d167ce79901d881'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip()
env = dict(os.environ, PYTHONPATH=str(root)+':'+str(root/'shared'), SENTINEL_REPO_ROOT=str(root))
if phase == 'physical':
    env['SENTINEL_PUBLICATION_RECEIPT_KEY'] = 'test-only-receipt-key-' * 4
    destination = root/'tests/audit399_certification'
    destination.mkdir()
    for name in ('test_snapshot_retention_restore.py','test_physical_retention_replay.py'):
        shutil.copyfile(Path('/repo/.codex-tmp/audit399-source/tests/audit399_certification')/name,destination/name)
    command = [sys.executable,'-m','pytest','-q','--tb=short','--show-capture=no','-p','no:cacheprovider',
        '-o','junit_family=xunit1','tests/audit399_certification/test_physical_retention_replay.py',
        '--junitxml=/evidence/physical-qualified.xml']
elif phase == 'lifecycle':
    command = [sys.executable,'tools/internal_state_harness.py','--scenario','populated_lifecycle',
        '--scenario','submit_process_death','--scenario','partial_cancel_fill_race',
        '--seeds','0','--output','/evidence/clean-lifecycle-fixed']
else:
    raise SystemExit('unknown clean replay')
print(head, json.dumps(command),flush=True)
started = time.monotonic()
label = phase + ('-qualified' if phase == 'physical' else '-fixed')
with open('/evidence/'+label+'.log','w') as log:
    result = subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record = dict(commit=head,command=command,exit_code=result.returncode,seconds=time.monotonic()-started)
Path('/evidence/'+label+'.command.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
print(Path('/evidence/'+label+'.log').read_text()[-7000:],flush=True)
raise SystemExit(result.returncode)
