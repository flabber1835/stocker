import io, json, os, subprocess, sys, tarfile, tempfile
from pathlib import Path

evidence = Path('/evidence')
historical = '5afba080859f25ea65fdb82da9ba54b442bac368'
root = Path(tempfile.mkdtemp(prefix='historical-golden-'))
archive = subprocess.check_output(['git','archive',historical,'shared'], cwd='/repo')
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    tar.extractall(root, filter='data')
diagnostic = '/repo/.codex-tmp/audit399-source/tests/audit399_continued/golden_diagnostic.py'
for label, source in [('historical', root), ('pinned', Path('/repo'))]:
    env = dict(os.environ, PYTHONPATH=str(source/'shared')+':'+str(source))
    command = [sys.executable, diagnostic, label]
    result = subprocess.run(command, env=env, cwd=root, text=True, capture_output=True)
    (evidence/('golden-'+label+'.log')).write_text(result.stdout+result.stderr)
    print(result.stdout, result.stderr, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
result = subprocess.run([sys.executable,'-m','pytest','-q','-p','no:cacheprovider',
    '/repo/.codex-tmp/audit399-source/tests/audit399_continued/test_golden_reconciliation.py',
    '--junitxml=/evidence/golden-reconciliation.xml'], cwd='/repo', text=True, capture_output=True)
(evidence/'golden-reconciliation.log').write_text(result.stdout+result.stderr)
print(result.stdout, result.stderr, flush=True)
raise SystemExit(result.returncode)
