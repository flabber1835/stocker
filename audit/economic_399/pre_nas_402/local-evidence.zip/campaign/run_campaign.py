import json, os, subprocess, sys, time
from pathlib import Path

phase = sys.argv[1]
evidence = Path('/evidence')
def run(label, args, env=None, cwd='/repo'):
    cmd = [sys.executable, *args]
    print('RUN', label, json.dumps(cmd), flush=True)
    start = time.monotonic()
    with (evidence / (label+'.log')).open('w') as log:
        result = subprocess.run(cmd, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = dict(label=label, command=cmd, cwd=cwd, exit_code=result.returncode,
                  seconds=time.monotonic()-start)
    (evidence/(label+'.command.json')).write_text(json.dumps(record, indent=2))
    print(json.dumps(record), flush=True)
    print((evidence/(label+'.log')).read_text()[-3500:], flush=True)
    return result.returncode

def pytest(label, paths, env=None, cwd='/repo'):
    return run(label, ['-m','pytest','-q','--tb=short','--show-capture=no','-p','no:cacheprovider',
                      '-o','junit_family=xunit1','--junitxml=/evidence/'+label+'.xml', *paths], env, cwd)

if phase == 'acceptance':
    names = '''alert_attempt_fencing cash_grace_identity economic_boundaries execution_callback_death
historical_cycle_recovery historical_command_symbol native_fill_acceptance native_fill_progression
nav_quantity_precision planless_action_units recovery_capability_boundary recovery_numeric_identity
retained_coverage_closure rolling_audit_acceptance rolling_restore_integrity sparse_entitlement_scope
terminal_leadership_return terminal_split_return unknown_absence_finality'''.split()
    paths = ['tests/sentinel/test_'+n+'.py' for n in names]
    paths += ['tests/sentinel/test_operational_snapshot.py::test_expired_first_attempt_gets_one_fresh_successor']
    raise SystemExit(pytest('acceptance', paths, dict(os.environ, SENTINEL_RECOVERED_ORDER_AUTHORITY='STRICT_V1')))
elif phase == 'regression':
    names = '''journal_and_reconcile automation_outbox operator_monitoring high_impact_durable_remediation
automation_runtime automation_service paper_performance_quarantine alpaca_boundary_overlay
alpaca_activity_sse_accounting p0_recovery_and_staleness issue270_restore_validation ownership
shadow_static_ownership broker_conformance'''.split()
    raise SystemExit(pytest('regression', ['tests/sentinel/test_'+n+'.py' for n in names]))
elif phase == 'strategy':
    raise SystemExit(pytest('strategy', ['tests/champion','tests/median5','tests/v5',
        'tests/sentinel/test_economic_boundaries.py','tests/sentinel/test_nav_quantity_precision.py',
        'tests/sentinel/test_terminal_leadership_return.py','tests/sentinel/test_terminal_split_return.py',
        'tests/wealth_core/test_state_machine.py']))
elif phase == 'mutations':
    codes = [run('mutation-'+name, ['tools/economic_audit_mutation_check.py',name])
             for name in ('fills','coverage','attempt','durable-fills','terminal-split','restore-origin','push-attempt')]
    codes += [run('mutation-v5',['tools/v5_mutation_check.py']),run('mutation-champion',['tools/champion_mutation_check.py'])]
    raise SystemExit(any(codes))
elif phase == 'cash-crash':
    root = '/repo/.codex-tmp/audit399-source/audit/economic_399'
    raise SystemExit(pytest('cash-crash', [root+'/continuation_20260918_action_coverage/test_cash_commit_boundaries.py',
        root+'/continuation_20260918/test_cash_transaction_closure.py'],
        dict(os.environ, SENTINEL_RECOVERED_ORDER_AUTHORITY='STRICT_V1')))
elif phase == 'restore-push':
    raise SystemExit(pytest('restore-push', ['tests/sentinel/test_rolling_restore_integrity.py',
        'tests/sentinel/test_web_push_attempt_fencing.py'],
        dict(os.environ, SENTINEL_RECOVERED_ORDER_AUTHORITY='STRICT_V1')))
elif phase == 'golden-unmasked':
    raise SystemExit(pytest('golden-unmasked', ['--runxfail',
        'tests/wealth_core/test_golden_fixture.py::test_the_result_matches_the_pinned_fixture',
        'tests/wealth_core/test_golden_fixture.py::TestTheHashesAreInterpreterIndependent::test_the_run_hash_is_stable_in_a_FRESH_INTERPRETER',
        'tests/wealth_core/test_performance_integration.py::test_measuring_does_not_move_the_pinned_result_hash']))
elif phase == 'predecessor':
    raise SystemExit(pytest('predecessor-fixed', ['tests/sentinel/test_strict_recovery_predecessor.py',
        'tests/sentinel/test_issue282_restore_upgrade_fence.py']))
elif phase == 'sse-wire':
    result = pytest('sse-wire', ['tests/sentinel/test_alpaca_postclose_candidates.py',
        'tests/sentinel/test_alpaca_activity_sse_accounting.py', 'tests/sentinel/test_alpaca_boundary_overlay.py',
        'tests/sentinel/test_trial_fill_interval_evidence.py','tests/sentinel/test_trial_fill_interval_proof.py'])
    mutation = run('mutation-snapshot-replay', ['tools/economic_audit_mutation_check.py','snapshot-replay'])
    raise SystemExit(bool(result or mutation))
else:
    raise SystemExit('unknown campaign')
