import ast, json, subprocess, sys
from collections import Counter
from pathlib import Path
import psycopg
from tests.support.postgres import _find_pg_bin

def git(*args):
    return subprocess.check_output(['git',*args],text=True).splitlines()
files = json.loads(Path('/evidence/changed-python.json').read_text(encoding='utf-8-sig'))
for name in files:
    compile(Path(name).read_bytes(),name,'exec')
result = {'python':sys.version,'psycopg':psycopg.__version__,
    'postgres':subprocess.check_output([_find_pg_bin('postgres'),'--version'],text=True).strip(),
    'head':git('rev-parse','HEAD')[0], 'compiled':files}
sys.path.insert(0, '/repo/.codex-tmp/lint-deps')
from pyflakes.checker import Checker
introduced = []
prior_count = 0
for name in files:
    old = subprocess.run(['git','show','97a5fb45f010848dc68569b91b611494a589c59a:'+name],capture_output=True,text=True)
    previous = Counter(m.message % m.message_args for m in Checker(ast.parse(old.stdout),name).messages) if old.returncode == 0 else Counter()
    prior_count += sum(previous.values())
    for m in Checker(ast.parse(Path(name).read_bytes()),name).messages:
        message = m.message % m.message_args
        if previous[message]: previous[message] -= 1
        else: introduced.append(f'{name}:{m.lineno}: {message}')
result.update(baseline_lint_findings=prior_count, introduced_lint_findings=introduced)
Path('/evidence/source-check-final.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k != 'compiled'},indent=2))
print('Compiled',len(files),'Python files')
raise SystemExit(bool(introduced))
