from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('C:/GitHub/stocker/.codex-tmp/status-cost-delivery-worktree')
SCRATCH = ROOT.parent
OUT = ROOT/'audit/economic_399/status_cost'
MEASURED = '9bececa241052c43851f5da586499a6ae3a8039f'
INTEGRATED = 'ffbf82b127784c145d697078ad1e8c03b70a0c46'
DIRECTORIES = [
    'status-cost-profile-baseline', 'status-cost-profile-after',
    'status-cost-isolated-100', 'status-cost-isolated-100-v2',
    'status-cost-isolated-5000', 'status-cost-storage-5000',
    'status-cost-storage-5000-final', 'status-cost-storage-5000-exact',
    'status-cost-isolated-5000-final', 'status-cost-pg16',
    'status-cost-main-integration-100', 'status-cost-backtester-source',
]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n', encoding='utf-8', newline='\n')


def main():
    files = [p for p in SCRATCH.glob('status-cost-*') if p.is_file()]
    for name in DIRECTORIES:
        files.extend(p for p in (SCRATCH/name).rglob('*') if p.is_file())
    files = sorted(files)
    # Every campaign must have reached its finally block before packaging.
    for name in [n for n in DIRECTORIES if 'profile' not in n and 'backtester-source' not in n]:
        assert any((SCRATCH/name).glob('*inspect.json')), name
    raw = {}
    with zipfile.ZipFile(OUT/'raw-logs.zip', 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in files:
            member = path.relative_to(SCRATCH).as_posix()
            data = path.read_bytes()
            info = zipfile.ZipInfo(member, date_time=(2026, 9, 20, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
            raw[member] = {'sha256': sha(data), 'bytes': len(data)}
    write('raw-log-sha256.json', raw)
    observations = {}
    for path in files:
        if path.suffix != '.log':
            continue
        values = []
        for line in path.read_text(encoding='utf-8-sig', errors='replace').splitlines():
            if not line.startswith('{'):
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                values.append(value)
        if values:
            observations[path.relative_to(SCRATCH).as_posix()] = values
    write('measurements.json', {
        'scope': 'SYNTHETIC_RESOURCE_AND_ACCOUNTING_ONLY',
        'measured_production_commit': MEASURED,
        'integrated_delivery_source_commit': INTEGRATED,
        'initial_verified_main': 'e255a78aaf4f89d25fc634864aafd2656c6cd176',
        'integrated_verified_main': '8bf86ed8ca1e9fa2a6cbb9ac1588c8bcda8712bb',
        'delivery_integrated_main': '67b6301e3b0f1c35dc41eb45367e96a449dd6e76',
        'delivery_review_checkpoint': '4812aa4beeecc29034a559c1ac0276ae9bff9ce6',
        'classifications': {
            'status-cost-isolated-5000': 'REAL_POSTGRES_OOM_DURING_INITIALIZATION',
            'status-cost-storage-5000-final': 'REAL_POSTGRES_OOM_DURING_OLD_GENESIS_EQUALITY',
            'status-cost-storage-5000': 'DIAGNOSTIC_ONLY_REJECTED_LOSSY_FLOAT_COMPARISON',
            'status-cost-storage-5000-exact': 'EXACT_STORAGE_DIAGNOSTIC_PG17',
            'status-cost-pg16': 'EXACT_STORAGE_DIAGNOSTIC_AND_30_TESTS_PG16',
            'status-cost-isolated-100': 'FAILED_PROBE_MECHANICS_NOT_ACCEPTANCE',
            'status-cost-isolated-100-v2': 'SMOKE_ONLY_BEFORE_STORAGE_FIX',
            'status-cost-isolated-5000-final': 'COMPLETE_SYNTHETIC_PIPELINE_PG17',
            'status-cost-main-integration-100': 'CURRENT_MAIN_SMOKE_NOT_BREADTH_QUALIFICATION',
        },
        'observations': observations,
    })
    common = ['sentinel/core/session.py', 'sentinel/core/decision.py',
              'sentinel/shadow_observation.py', 'sentinel/observation_storage.py',
              'sentinel/paper_performance.py', 'tests/sentinel/test_status_memory.py',
              'tests/sentinel/test_panel_concurrency.py',
              'audit/economic_399/full_status/probe.py',
              'audit/economic_399/status_memory/economic_oracle.py',
              'audit/economic_399/status_cost/stages.py',
              'audit/economic_399/status_cost/run_stages.py',
              'audit/economic_399/status_cost/call_profile.py',
              'audit/economic_399/status_cost/mutations.py',
              'audit/economic_399/status_cost/storage_mutations.py']
    sources = {}
    for commit in [MEASURED, INTEGRATED]:
        paths = common + (['audit/economic_399/status_cost/postgres16.py'] if commit == INTEGRATED else [])
        sources[commit] = {p: sha(git('show', commit+':'+p)) for p in paths}
    inventory_commit = git('rev-parse', 'df64828b').decode().strip()
    inventory_path = 'audit/economic_399/status_cost/pit_inventory.py'
    sources[inventory_commit] = {inventory_path: sha(git('show', inventory_commit+':'+inventory_path))}
    backtester_commit = 'e088bfd26c695309e259cfc44ab1e8982d6f858d'
    sources[backtester_commit] = {p: sha(git('show', backtester_commit+':'+p)) for p in [
        'backtester/data/canonical-pit-20y.json', 'backtester/STRICT_PIT_CERTIFICATION_RUNBOOK.md',
        'backtester/canonical_pit_dataset.py', 'backtester/canonical_pit_package.py',
        '.github/workflows/backtester-production-strict-pit-20y.yml',
        'backtester/run_production_current_main_strict_pit_20y.py',
        'backtester/data/production-chain-generation.json']}
    write('source-sha256.json', sources)
    artifact_paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'artifact-sha256.json')
    artifact_paths += [ROOT/'docs'/p for p in ['status-runtime-cost.md', 'economic-code-closure.md', 'sentinel-deployment.md']]
    write('artifact-sha256.json', {p.relative_to(ROOT).as_posix(): {
        'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in artifact_paths})
    with zipfile.ZipFile(OUT/'raw-logs.zip') as archive:
        assert sorted(archive.namelist()) == sorted(raw)
        for name, value in raw.items():
            data = archive.read(name)
            assert sha(data) == value['sha256'] and len(data) == value['bytes']
    for commit, entries in sources.items():
        for path, digest in entries.items():
            assert sha(git('show', commit+':'+path)) == digest
    print(json.dumps({'raw_members_verified': len(raw), 'source_blobs_verified': sum(map(len, sources.values())),
                      'artifact_files_hashed': len(artifact_paths), 'zip_bytes': (OUT/'raw-logs.zip').stat().st_size}))


if __name__ == '__main__':
    main()
