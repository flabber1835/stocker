"""Convergence after absence, and re-projection after external cash.

## The rule this enforces

```text
historical sessions advance DETERMINISTIC STATE.
historical EXECUTION INTENT is never replayed.
```

`docs/sentinel-execution-contract.md` states it; `executor._assert_current_plan`
refuses to run a superseded plan; and until now nothing PRODUCED the single
surviving intent that rule presupposes. The obvious implementation of "we were
offline for three days" walks the missed sessions and executes each one:

```text
Monday      controller wanted 0%       ->  liquidate
Tuesday     controller wanted 55%      ->  re-enter
Wednesday   controller wanted 100%     ->  rotate
Thursday    controller wants 100%      ->  ...
```

All four fire at Thursday's prices, against Thursday's book. Three round trips
of slippage and commission to arrive where one Thursday plan arrives directly —
and the first of them liquidates a live account because of what a Monday that
is over wanted.

So `catch_up` replays the state and emits ONE plan. Peaks, ages, review clocks,
cooldowns and exposure all advance exactly as they would have; the broker sees
a single intent, for now.

## The pointer is durable and advances WITH the state

`last_processed_session` is a row, written in the same transaction as the state
the session produced. Written after the whole loop instead, a crash replays
sessions that already advanced — and Wealth Core's state is path-dependent, so
a replayed session double-ages every episode. Written before, a crash SKIPS a
session, which is the silent one.

## The state transition remains an explicit seam

`advance_state` and `decide` are injected so this transaction coordinator stays
independent of strategy and broker implementation details. Production supplies
the canonical version-3 `SessionState` transition through
`core.production.advance_and_persist` and the current-plan decision adapter;
tests may supply smaller deterministic seams. That preserves one catch-up and
one durability implementation without creating a second portfolio or state
machine.

## Re-projection is not replay

An external cash flow changes what is investable. It does not change what
Wealth Core did — the historical book is a function of PRICE history, and no
peak, age or cooldown moves because money arrived. `reproject` re-sizes the
CURRENT target against the new NAV and advances nothing.
"""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Callable, Mapping, Optional

from sentinel.core.cashflow import Attribution, NavReconciliation
from sentinel.execution import journal
from sentinel.execution.plan import ExecutionPlan


class StateNotDurable(TypeError):
    """The state a seam returned cannot be encoded, so it cannot be made atomic
    with the pointer — which is the entire guarantee.

    Raised at the FIRST session rather than at the end. A four-hour replay that
    discovers this on its last step has lost the run; one that refuses
    immediately has cost a clear error message.
    """


class StateCommitmentMismatch(RuntimeError):
    """Canonical production restart state no longer matches its durable plan.

    A path-dependent state is authority, not a cache. Once a production plan
    commits to its state hash, a later restart may advance that state only if
    the exact commitment still holds. This makes a valid-looking SQL mutation
    a refusal instead of allowing it to become a new self-consistent strategy
    path on the next session.
    """


class NavUnobserved(RuntimeError):
    """A re-projection was attempted with no NAV.

    Refused rather than defaulted. Sizing a basket against a guessed balance
    produces a confident wrong order, and the guess would be wrong by exactly
    the amount of the flow that prompted the re-projection.
    """


@dataclass
class CatchUpResult:
    sessions_replayed: int
    through: date
    plan: Optional[ExecutionPlan]
    superseded: int = 0
    state: object = None
    caveats: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"sessions_replayed": self.sessions_replayed,
                "through": self.through.isoformat(),
                "plan": self.plan.to_dict() if self.plan else None,
                "superseded_plans": self.superseded,
                "caveats": list(self.caveats)}


@dataclass
class Reprojection:
    """A re-sized current target, and what execution is permitted to do with it."""

    plan: Optional[ExecutionPlan]
    #: Desired shares minus held minus already-committed. The number that stops
    #: a re-projection during a partial fill from buying the position twice.
    remaining: dict = field(default_factory=dict)
    #: Securities with a WORKING order that must be cancelled and CONFIRMED
    #: cancelled before the new intent is sized against them. Never silently
    #: superseded: declaring a live order superseded abandons it.
    cancel_first: tuple = ()
    #: Only reductions may proceed. Set when the inputs are good enough to sell
    #: on and not good enough to buy on — the missed-open asymmetry.
    reduction_only: bool = False
    caveats: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"plan": self.plan.to_dict() if self.plan else None,
                "remaining": {k: str(v) for k, v in sorted(self.remaining.items())},
                "cancel_first": list(self.cancel_first),
                "reduction_only": self.reduction_only,
                "caveats": list(self.caveats)}


# ── the durable pointer ──────────────────────────────────────────────────────

#: One row, one meaning. A table with many rows would invite "the latest by
#: timestamp", and a clock is not an ordering of trading sessions.
_CURSOR = "catchup"
_RESUME_COMMITMENT_CURSOR = "catchup:resume_commitment:v1"


def last_processed_session(conn) -> Optional[date]:
    with conn.cursor() as cur:
        cur.execute("SELECT session FROM sentinel_processed_sessions"
                    " WHERE cursor_name = %s", (_CURSOR,))
        row = cur.fetchone()
    return None if row is None else _d(row[0])


def _canonical_hash(value) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def _resume_commitment(state, plan, session: date) -> dict:
    return {"schema": "sentinel.catchup-resume/1", "session": session.isoformat(),
            "state_sha256": _canonical_hash(state), "anchor_plan_id": plan.plan_id,
            "anchor_plan_fingerprint": plan.fingerprint()}


def _matches_resume_commitment(conn, state, plan, cursor: date) -> bool:
    with conn.cursor() as cur:
        cur.execute("SELECT session,state FROM sentinel_processed_sessions"
                    " WHERE cursor_name=%s", (_RESUME_COMMITMENT_CURSOR,))
        row = cur.fetchone()
    if row is None or _d(row[0]) != cursor:
        return False
    try:
        record = row[1] if isinstance(row[1], dict) else json.loads(row[1])
    except (TypeError, ValueError):
        return False
    return record == _resume_commitment(state, plan, cursor)


def _record_resume_commitment(conn, state, session: date) -> None:
    from sentinel.core.production import SessionState
    if not isinstance(state, Mapping):
        return
    try:
        canonical = SessionState.from_dict(state)
    except (KeyError, TypeError, ValueError) as exc:
        if {"wealth_core", "strategy_identity"} <= set(state):
            raise StateCommitmentMismatch("invalid canonical checkpoint state") from exc
        return  # Generic test/research seams retain their existing contract.
    plan = journal.latest_plan(conn)
    if (plan is None or not str(plan.plan_id).startswith("sentinel-")
            or not plan.shadow_snapshot_hash or not plan.sentinel_transition_hash
            or not plan.strategy_fingerprint):
        return
    if (canonical.last_processed_session != session.isoformat()
            or plan.decision_session >= session
            or _canonical_hash(canonical.strategy_identity) != plan.strategy_fingerprint):
        raise StateCommitmentMismatch("intermediate catch-up commitment has inconsistent authority")
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO sentinel_processed_sessions (cursor_name,session,state)"
            " VALUES (%s,%s,%s::jsonb) ON CONFLICT (cursor_name) DO UPDATE SET"
            " session=EXCLUDED.session,state=EXCLUDED.state,updated_at=NOW()",
            (_RESUME_COMMITMENT_CURSOR, session.isoformat(),
             json.dumps(_resume_commitment(state, plan, session), sort_keys=True)))


def _assert_resume_state_commitment(conn, state) -> None:
    """Verify production `SessionState` against the prior durable plan.

    A row declaring Wealth Core and strategy identity must decode as canonical
    production state. Its commitment is checked against the durable current
    Sentinel production plan. Generic JSON state retains its existing caller
    contract.
    """
    if not isinstance(state, Mapping):
        return
    try:
        # Lazy import keeps the generic coordinator independent at module load
        # time and avoids a production<->catchup import cycle.
        from sentinel.core.production import SessionState
        canonical = SessionState.from_dict(state)
    except (KeyError, TypeError, ValueError) as exc:
        if {"wealth_core", "strategy_identity"} <= set(state):
            raise StateCommitmentMismatch("invalid canonical restart state") from exc
        return

    plan = journal.latest_plan(conn)
    if plan is None:
        # A genuinely fresh canonical state can exist briefly before its first
        # plan. Once any execution-plan history exists, losing the current
        # commitment is corruption rather than permission to mint a new one.
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM sentinel_execution_plans")
            prior_plan_count = int(cur.fetchone()[0])
        if prior_plan_count:
            raise StateCommitmentMismatch(
                "canonical restart state has execution-plan history but no "
                "durable current plan commitment")
        return

    # Research/reprojection plans are not the production state commitment and
    # deliberately do not carry the fields below. Do not reinterpret them.
    if (not str(plan.plan_id).startswith("sentinel-")
            or not plan.shadow_snapshot_hash
            or not plan.sentinel_transition_hash
            or not plan.strategy_fingerprint):
        return

    cursor = last_processed_session(conn)
    if cursor is None:
        raise StateCommitmentMismatch(
            "canonical restart state has a plan but no processed-session cursor")
    if canonical.last_processed_session != cursor.isoformat():
        raise StateCommitmentMismatch(
            "canonical restart state and processed-session cursor disagree")
    if plan.decision_session != cursor:
        if (plan.decision_session < cursor
                and _canonical_hash(canonical.strategy_identity) == plan.strategy_fingerprint
                and _matches_resume_commitment(conn, state, plan, cursor)):
            return
        raise StateCommitmentMismatch(
            "canonical restart cursor is not the prior committed plan session")
    if canonical.state_hash != plan.shadow_snapshot_hash:
        raise StateCommitmentMismatch(
            "canonical restart state fingerprint does not match the prior "
            "committed plan")
    if _canonical_hash(canonical.last_decision) != plan.sentinel_transition_hash:
        raise StateCommitmentMismatch(
            "canonical restart controller transition does not match the prior "
            "committed plan")
    if _canonical_hash(canonical.strategy_identity) != plan.strategy_fingerprint:
        raise StateCommitmentMismatch(
            "canonical restart strategy fingerprint does not match the prior "
            "committed plan")
    if canonical.data_version != plan.data_version:
        raise StateCommitmentMismatch(
            "canonical restart data version does not match the prior committed "
            "plan")


def resume_state(conn):
    """The state catch-up last persisted, or None.

    What a RESTART reads. Without it a resumed run hands the seam `None` and
    the seam has no history to advance from — so the sessions after a crash
    would be replayed against an empty book, which is a quieter version of the
    skip this whole mechanism exists to prevent.

    Canonical production state is additionally checked against the durable plan
    that committed it. A later decision therefore cannot launder a valid JSON
    mutation into a new strategy path simply because the cursor still agrees.
    """
    with conn.cursor() as cur:
        cur.execute("SELECT state FROM sentinel_processed_sessions"
                    " WHERE cursor_name = %s", (_CURSOR,))
        row = cur.fetchone()
    if row is None or row[0] is None:
        return None
    state = row[0] if isinstance(row[0], (dict, list)) else json.loads(row[0])
    _assert_resume_state_commitment(conn, state)
    return state


def _encode(state) -> Optional[str]:
    if state is None:
        return None
    try:
        # NO `default=`. A fallback coercion makes EVERYTHING encodable and
        # nothing round-trip: `Decimal("1.5")` goes out as the string "1.5" and
        # comes back as a string, so the resumed book is quietly not the book
        # that was saved. For money that is worse than refusing — the seam must
        # hand over something that survives the trip, and being told so at
        # session one is cheap.
        return json.dumps(state, sort_keys=True)
    except (TypeError, ValueError) as exc:
        raise StateNotDurable(
            f"catch-up cannot encode the state this seam returned "
            f"({type(state).__name__}): {exc}. It has to be written in the same "
            f"statement as the pointer, or the pointer can outlive it — and a "
            f"pointer ahead of the state SKIPS a session permanently. Give "
            f"`advance_state` a JSON-serialisable return, or have it persist "
            f"through the `conn` it is handed and return a handle to that.") \
            from exc


def _mark_processed(conn, session: date, state=None) -> None:
    """The pointer and the state, in ONE statement.

    This is the enforcement that does not depend on the seam's cooperation.
    `advance_state` is handed the transaction and can write through it, but
    nothing can make it — so catch-up also persists whatever it was handed,
    beside the cursor, in the same row. A pointer that is durable while the
    state is not is a session skipped permanently and silently.

    NEVER MOVES BACKWARDS. A caller replaying an old window must not rewind the
    frontier of what has already advanced — that is how a session gets aged
    twice. The state follows the same guard: it is only replaced when the
    session actually advances, so a rewind attempt cannot install an older
    book under a newer pointer.
    """
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO sentinel_processed_sessions (cursor_name, session,"
            " state) VALUES (%s,%s,%s) ON CONFLICT (cursor_name) DO UPDATE SET"
            "   session = GREATEST(sentinel_processed_sessions.session,"
            "                      EXCLUDED.session),"
            "   state = CASE WHEN EXCLUDED.session"
            "                     >= sentinel_processed_sessions.session"
            "                THEN EXCLUDED.state"
            "                ELSE sentinel_processed_sessions.state END,"
            "   updated_at = NOW()",
            (_CURSOR, session.isoformat(), _encode(state)))


# ── catch-up ─────────────────────────────────────────────────────────────────

def catch_up(conn, *, through, missed, advance_state: Callable,
             decide: Callable, state=None) -> CatchUpResult:
    """Advance deterministic state across `missed`, then emit ONE plan.

    `advance_state(conn, session, state) -> state` is the deterministic step:
    Wealth Core's session, and the controller's. It must not touch a broker.

    IT RECEIVES THE TRANSACTION, and that is the point of the signature. A seam
    handed only `(session, state)` can satisfy the contract with a plain Python
    object, which is exactly what every test did — and then the only durable
    half is the pointer. A crash after the commit leaves the cursor saying Aug
    10 is done while the book still says Aug 9, and Aug 10 is skipped
    permanently and silently.

    Being handed `conn` makes the correct thing possible; it cannot make it
    happen. So `_mark_processed` ALSO persists whatever this returns, in the
    same statement as the pointer — two enforcements, because either alone is
    escapable.

    **`advance_state` MUST NOT COMMIT.** This is the one failure no arrangement
    here can prevent, and it is stated rather than implied because a mutation
    sweep found it: a seam that commits its own writes has made ITS state
    durable ahead of the pointer, so a crash then replays a session that
    already happened and double-ages every episode. What survives is that
    catch-up's own copy never disagrees with catch-up's own pointer, so a
    restart resumes from a coherent pair and the seam's over-advance is
    DETECTABLE by comparing the two rather than silent.

    `decide(session, state) -> ExecutionPlan | None` is called ONCE, for the
    final session. Calling it per session and keeping the last would be the
    same result at four times the cost and would tempt someone to execute the
    intermediates.

    Sessions at or before `last_processed_session` are skipped: the state is
    path-dependent, so replaying one double-ages every episode in the book.
    """
    with journal.writer_lock(conn):
        try:
            return catch_up_locked(conn, through=through, missed=missed,
                                   advance_state=advance_state, decide=decide,
                                   state=state)
        except BaseException:
            # ROLL BACK THE SESSION THAT DID NOT FINISH.
            #
            # A killed process gets this from the server for free. A raised
            # exception on a connection that SURVIVES does not: the failed
            # session's writes sit uncommitted in an open transaction, visible
            # to this connection and to nothing else, and the next caller
            # inherits them. That is a pointer and a state that disagree by
            # exactly one session — the fault this whole mechanism exists to
            # make impossible, arriving through the error path.
            conn.rollback()
            raise


def catch_up_locked(conn, *, through, missed, advance_state: Callable,
                    decide: Callable, state=None) -> CatchUpResult:
    """`catch_up` while the caller already holds the single-writer lock.

    Production preparation holds that lock across its broker reconciliation,
    corpus pin, state transition and plan adoption. Releasing and reacquiring it
    between those acts would make the evidence used for the plan stale before
    the plan became current. Ordinary callers should use :func:`catch_up`.
    """
    try:
        return _catch_up_locked(conn, through=_d(through),
                                missed=[_d(m) for m in missed],
                                advance_state=advance_state, decide=decide,
                                state=state)
    except BaseException:
        conn.rollback()
        raise


class SessionsIncomplete(ValueError):
    """`missed` is not the exchange's own list of sessions through `through`.

    Catch-up used to take the caller's word for it and then, having advanced
    only over what it was given, mark `through` processed UNCONDITIONALLY:

    ```text
    last processed  Monday
    missed          [Tuesday, Thursday]
    through         Friday
    ```

    Wednesday and Friday never advanced Wealth Core or the controller, and the
    durable pointer then said Friday. Every later catch-up skips sessions at or
    before the pointer, so those two are gone — permanently and silently, which
    is the precise failure mode `_mark_processed` was written to close from the
    other direction.

    The authority is the certified XNYS calendar, not the argument. A list that
    disagrees with it is refused rather than repaired: a caller confused about
    which days are sessions is a caller whose STATE is about to be wrong, and
    quietly substituting the right answer hides that.
    """


def _expected_sessions(start: date, through: date) -> list[date]:
    """Every exchange session in `[start, through]`, from the certified XNYS
    calendar. Weekends and holidays are simply absent, because they are not
    sessions."""
    from sentinel.feed import calendar as cal

    if start > through:
        return []
    return [date.fromisoformat(s) for s in cal.sessions_in_range(start, through)]


def _catch_up_locked(conn, *, through: date, missed, advance_state, decide,
                     state) -> CatchUpResult:
    done = last_processed_session(conn)

    # ── THE LIST IS PROVEN, NOT TRUSTED ──────────────────────────────────────
    #
    # `owed` used to be `sorted(s for s in missed if s > done)` and nothing
    # compared it to reality. Then `_mark_processed(conn, through, state)` ran
    # unconditionally at the end, so a caller could advance two sessions and
    # move the pointer four days — losing the two in between forever.
    #
    # Derived from the calendar rather than filtered from the argument, so the
    # sessions that RUN are the exchange's, and the argument only has to agree.
    supplied = sorted(set(missed))
    if len(supplied) != len(list(missed)):
        raise SessionsIncomplete(
            f"`missed` contains duplicates: {sorted(str(m) for m in missed)}. "
            f"Normalising them away would hide a caller that believes it is "
            f"asking for two advances of one session, and a double advance "
            f"double-ages every episode in the book.")

    # Sessions AT OR BEFORE the pointer are already processed and are dropped,
    # not refused — a resuming caller reports everything it believes it missed
    # without knowing where the pointer got to, and that is the normal path
    # after a partial run.
    unprocessed = [s for s in supplied if done is None or s > done]

    # WHERE TO START LOOKING. After the pointer when there is one. On a fresh
    # appliance there is nothing to anchor to, so the caller's own earliest
    # session is the anchor — contiguity and session-validity are still proven
    # from there; only the left edge is the caller's to choose.
    if done is not None:
        start = done + timedelta(days=1)
    elif unprocessed:
        start = unprocessed[0]
    else:
        start = through
    owed = _expected_sessions(start, through)

    if unprocessed != owed:
        not_sessions = [s.isoformat() for s in unprocessed if s not in owed]
        omitted = [s.isoformat() for s in owed if s not in unprocessed]
        raise SessionsIncomplete(
            f"`missed` is not the exchange's session list through {through}. "
            f"expected {[s.isoformat() for s in owed]}; "
            f"got {[s.isoformat() for s in unprocessed]}"
            + (f"; NOT SESSIONS (weekend/holiday) or after {through}: "
               f"{not_sessions}" if not_sessions else "")
            + (f"; OMITTED: {omitted}" if omitted else "")
            + ". Refused rather than repaired: a caller confused about which "
              "days are sessions is a caller whose STATE is about to be wrong, "
              "and marking `through` processed would bury the omitted ones "
              "permanently — every later catch-up skips at or before the "
              "pointer.")

    # A RESTART HANDS US NOTHING. Read what the last run left, or the resumed
    # sessions advance against an empty book — a quieter version of the skip
    # this whole mechanism exists to prevent.
    if state is None:
        state = resume_state(conn)

    replayed = 0
    for index, session in enumerate(owed):
        # ONE TRANSACTION per session, and the seam is handed the connection so
        # it can write its own durable state inside it. Nothing can force it to
        # — so `_mark_processed` also persists whatever it returns, in the same
        # statement as the pointer. Split them and a crash between the two
        # either replays a session (double ageing, at least visible) or skips it
        # (silent, permanent, and the worse one).
        state = advance_state(conn, session.isoformat(), state)
        _mark_processed(conn, session, state)
        # Preserve the exact canonical strategy facts in the SAME transaction
        # as the cursor/state. Generic research/test seams are deliberately
        # ignored by the recorder; only a valid production SessionState can
        # enter the forward-trial evidence ledger.
        from sentinel import trial_evidence
        trial_evidence.record_strategy_session(
            conn, session=session.isoformat(), state=state)
        # Historical sessions become durable one at a time. The FINAL session
        # deliberately remains in this transaction until its one current plan
        # has been saved and every older plan superseded. Committing here left a
        # crash window in which the state said today while yesterday's plan was
        # still executable.
        if index < len(owed) - 1:
            _record_resume_commitment(conn, state, session)
            conn.commit()
        replayed += 1

    plan = decide(through.isoformat(), state)
    superseded = 0
    if plan is not None:
        journal.save_plan(conn, plan, commit=False)
        superseded = journal.supersede_all_but(
            conn, plan.plan_id, commit=False) or 0
        plan = journal.load_plan(conn, plan.plan_id)
    _mark_processed(conn, through, state)
    if (plan is not None and str(plan.plan_id).startswith("sentinel-")
            and plan.shadow_snapshot_hash and plan.sentinel_transition_hash
            and plan.strategy_fingerprint):
        with conn.cursor() as cur:
            cur.execute("DELETE FROM sentinel_processed_sessions WHERE cursor_name=%s",
                        (_RESUME_COMMITMENT_CURSOR,))
    conn.commit()

    return CatchUpResult(sessions_replayed=replayed, through=through,
                         plan=plan, superseded=superseded, state=state)


# ── projection ───────────────────────────────────────────────────────────────

def project(*, weights: Mapping[str, Decimal], nav: Decimal,
            exposure: Decimal, marks: Mapping[str, Decimal]) -> dict:
    """Target WEIGHTS at a given NAV -> target SHARES.

        shares = floor(nav * weight * exposure / mark)

    EXPOSURE SCALES THE BASKET, NEVER THE MEMBERSHIP. Sentinel decides how much
    of Wealth Core's book to hold, never what is in it — 0.55 buys every name at
    0.55x, it does not buy 55% of the names.

    FLOORED, not rounded. Rounding up buys a share the account cannot fund at
    the margin, and across 25 slots those roundings accumulate into leverage the
    envelope is supposed to exclude. Decimal throughout: this reaches a broker.

    A security with no mark is OMITTED rather than sized at zero. Zero is a
    target — "hold none of this" — and it would liquidate a position because a
    price was missing.

    **OMISSION IS NOT SUFFICIENT ON ITS OWN**, and this function cannot make it
    so: to a downstream reader an absent key and a zero are the same thing.
    `compute_delta` reads a missing basket entry as `desired = 0` and sells the
    lot. Whoever composes this into a plan must decide what an omitted-but-held
    security should be — see `unpriceable` and `reproject`, which set it to the
    quantity currently held so no economic decision is made at all.
    """
    out: dict = {}
    for sid, w in weights.items():
        mark = marks.get(sid)
        if not mark or mark <= 0:
            continue
        qty = (Decimal(nav) * Decimal(w) * Decimal(exposure)) / Decimal(mark)
        out[sid] = qty.to_integral_value(rounding="ROUND_FLOOR")
    return out


def unpriceable(weights: Mapping[str, Decimal],
                marks: Mapping[str, Decimal]) -> tuple:
    """Securities Wealth Core still WANTS and nothing can price.

    Separated from `project` because the distinction it enables is not about
    projection at all — it is about telling two situations apart that both end
    up as "no entry in the target basket":

    ```text
    not in weights        Wealth Core no longer wants it   -> SELL ALL
    in weights, no mark   we cannot value it               -> HOLD, no decision
    ```

    Only the first is a reason to sell, and selling it needs no mark: the share
    count is exactly known. The second is a data outage wearing a target's
    clothing, and treating it as one liquidates a position because a price was
    missing — the failure `project`'s docstring forbids and, before this
    existed, `reproject` performed anyway.
    """
    return tuple(sorted(sid for sid in weights
                        if not marks.get(sid) or marks[sid] <= 0))


def reproject(conn, *, session, nav: Optional[Decimal],
              weights: Mapping[str, Decimal], exposure: Decimal,
              marks: Mapping[str, Decimal],
              held: Optional[Mapping[str, Decimal]] = None,
              committed: Optional[Mapping[str, Decimal]] = None,
              marks_stale: bool = False,
              nav_reconciliation: Optional[NavReconciliation] = None,
              advance_state: Optional[Callable] = None) -> Reprojection:
    """Re-size the CURRENT target against a new NAV. Advances NOTHING.

    This is the whole difference between a cash flow and a market event. The
    historical book is a function of price history; a deposit changes what is
    investable and nothing else, so no session is replayed and
    `last_processed_session` does not move. `advance_state` is accepted only so
    a caller can assert it is never called.
    """
    if nav is None:
        raise NavUnobserved(
            "no NAV was observed, so the basket cannot be sized. The account "
            "balance is the one input a re-projection cannot guess — and the "
            "guess would be wrong by exactly the flow that prompted it. Retry "
            "when the broker answers; the declared flow is already durable.")

    d = _d(session)
    held = {k: Decimal(v) for k, v in (held or {}).items()}
    committed = {k: Decimal(v) for k, v in (committed or {}).items()}
    caveats: list = []

    desired = project(weights=weights, nav=nav, exposure=exposure, marks=marks)

    # A SECURITY WE CANNOT PRICE HOLDS WHAT IT HOLDS.
    #
    # `project` omits it, correctly refusing to guess a quantity. Left omitted,
    # that refusal becomes the opposite instruction the moment anything reads
    # the basket: `compute_delta` sees no entry, takes `desired = 0`, and sells
    # the position — and the sweep below would independently arrive at the same
    # place. "We cannot value this" and "we want none of this" are different
    # facts and only the second is a reason to sell.
    #
    # `held + committed`, not `held` alone: 40 owned with 60 working is a
    # position of 100 in flight, and a target of 40 would cancel the difference
    # while a target that ignored `committed` would order it twice.
    blind = unpriceable(weights, marks)
    for sid in blind:
        outstanding = held.get(sid, Decimal(0)) + committed.get(sid, Decimal(0))
        if outstanding:
            desired[sid] = outstanding
    if blind:
        caveats.append(
            f"NO MARK for {list(blind)} — held quantities are carried unchanged "
            f"and no purchase is sized. The corpus cannot value these today; "
            f"that is a data outage, not a target of zero, and selling on it "
            f"would liquidate a position because a price was missing.")

    # ── may this re-projection INCREASE exposure? ────────────────────────────
    #
    # The missed-open asymmetry, applied to input quality rather than to time.
    # Both of these degrade the SIZE of an order without degrading the
    # direction, so selling remains safe and buying does not: a reduction sized
    # slightly wrong still reduces, while a purchase sized against a stale mark
    # or an unaccounted balance commits real money at an unknown quantity.
    reduction_only = False
    if marks_stale:
        reduction_only = True
        caveats.append(
            "marks are STALE — the corpus has not advanced to this session. "
            "Reductions proceed: a withdrawal creates an obligation the account "
            "must meet, and doing nothing is not the conservative choice it "
            "looks like. Increases are refused.")
    if (nav_reconciliation is not None
            and nav_reconciliation.attribution is Attribution.UNEXPLAINED):
        reduction_only = True
        caveats.append(
            f"NAV is UNEXPLAINED by {nav_reconciliation.unexplained} — neither "
            f"marked P&L nor a declared flow accounts for the move. De-risking "
            f"is always permitted; increasing exposure against a balance nobody "
            f"can account for is not.")

    # A HELD SECURITY THE TARGET DOES NOT MENTION IS AN EXPLICIT ZERO.
    #
    # Wealth Core dropped it, so it is sold — and selling needs no mark, the
    # share count is exactly known. Written into the basket rather than left
    # absent because absent and zero are the same thing to `compute_delta`, and
    # a plan that relies on a reader's default is a plan that does not say what
    # it means. That ambiguity is precisely what turned an unpriceable security
    # into a liquidation one branch above.
    for sid in held:
        desired.setdefault(sid, Decimal(0))

    remaining = {
        sid: qty - held.get(sid, Decimal(0)) - committed.get(sid, Decimal(0))
        for sid, qty in desired.items()}

    if reduction_only and any(v > 0 for v in remaining.values()):
        increases = {k: str(v) for k, v in sorted(remaining.items()) if v > 0}
        caveats.append(
            f"increase(s) {increases} REFUSED. No plan is emitted rather than a "
            f"reduced one: a plan carrying only half of an intent is a plan "
            f"whose fingerprint says it was fully satisfied when it was not.")
        return Reprojection(plan=None, remaining=remaining,
                            reduction_only=True, caveats=caveats)

    plan = ExecutionPlan(
        plan_id=f"reproj-{uuid.uuid4().hex[:12]}",
        decision_session=d, effective_session=d,
        target_exposure=Decimal(exposure), target_basket=desired,
        data_version=_current_version(conn))
    journal.save_plan(conn, plan)
    journal.supersede_all_but(conn, plan.plan_id)
    conn.commit()

    # WORKING ORDERS ARE CANCELLED, NOT SUPERSEDED. Supersession retires an
    # UNSENT intent; a live order at the broker is a real obligation, and
    # declaring it superseded abandons it — the shares still arrive and nothing
    # is expecting them.
    cancel_first = tuple(sorted(sid for sid, q in committed.items() if q))

    return Reprojection(plan=journal.load_plan(conn, plan.plan_id),
                        remaining=remaining, cancel_first=cancel_first,
                        reduction_only=reduction_only, caveats=caveats)


def _current_version(conn) -> Optional[int]:
    from sentinel.feed import publication

    pub = publication.current(conn)
    return pub.version if pub else None


def _d(v) -> date:
    return v if isinstance(v, date) else date.fromisoformat(str(v))


__all__ = ["CatchUpResult", "NavUnobserved", "Reprojection",
           "StateCommitmentMismatch", "StateNotDurable",
           "catch_up", "last_processed_session", "project", "reproject",
           "resume_state", "unpriceable"]
